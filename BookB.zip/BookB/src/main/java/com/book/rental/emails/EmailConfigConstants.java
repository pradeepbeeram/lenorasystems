package com.book.rental.emails;

public class EmailConfigConstants {
	

public static final String ADMIN_FROM_EMAIL="bookrentalsystem.ucm@gmail.com";

public static final String  HOST_SMTP_END_POINT="smtp.gmail.com";


public static final String SMTP_USERNAME = "bookrentalsystem.ucm";  
public static final String SMTP_PASSWORD = "ucmStudent";  

public static final int SMTP_PORT=587;


public static final String WElCOME_EMAIL_SUBJECT = "Welcome to the Book Rental System  ";
public static final String WELCOME_EMAIL_BODY_PART1 = "\n\n\tThank you for signing up with  the Book Rental System . You can now access the Book Rental System by logining to your account."+"Browse through the Book available for Rentals.\n";
public static final String WELCOME_EMAIL_BODY_PART2 = " Regards,\n"+ "Book Rentals Team";
public static final String MIME_MAIL_FORMAT="text/html";



}
