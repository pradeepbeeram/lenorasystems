package com.book.rental.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.book.rental.dao.BiddingDetailsDao;
import com.book.rental.model.BiddingDetails;

@Service("biddingDetailsService")
@Transactional
public class BiddingDetailsServiceImpl implements BiddingDetailsService {

	@Autowired
	BiddingDetailsDao biddingDao;
	
	public Boolean saveBiddingDetails(BiddingDetails biddings) {
		return biddingDao.saveBiddingDetails(biddings);
	}

	public BiddingDetails getBiddingDetails(Integer AuctionId) {
		return biddingDao.getBiddingDetails(AuctionId);
	}

	public HashMap<Integer, Integer> getAuctionBookDetails(Integer studentId) {
		return biddingDao.getAuctionBookDetails(studentId);
	}
	
	@SuppressWarnings("rawtypes")
	public List getBidderDetails(Integer AuctionId){
		return biddingDao.getBidderDetails(AuctionId);
	}

	
	

}
