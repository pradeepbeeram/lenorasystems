package com.book.rental.delegates;

public class BookRentalSystemConstants {
	
	public static final String BOOK_STATUS_NEW = "New";
	
	public static final String BOOK_STATUS_INAUCTION = "InAuction";
	
	public static final String BOOK_STATUS_RENTED = "Rented";
	
	public static final String AUCTION_STATUS_OPEN = "Open";
	
	public static final String AUCTION_STATUS_IN_TRANSACTION = "InTransaction";
	
	public static final String AUCTION_STATUS_CLOSED = "Closed";
	
	public static final String TRANSACTION_STATUS_ASSIGNED = "Assigned";
	
	public static final String TRANSACTION_STATUS_BOOK_GIVEN = "Book Given";
	
	public static final String TRANSACTION_STATUS_COMPLETED = "Completed";

	

}
