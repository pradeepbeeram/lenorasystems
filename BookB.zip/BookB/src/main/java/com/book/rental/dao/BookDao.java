package com.book.rental.dao;


import java.util.List;

import com.book.rental.model.Book;

public interface BookDao {
	
	void saveBook(Book bookDetails);
	Book getBookDetails(Integer BookId);
	void deleteBook(Integer bookId);
	List<Book> findAllBooksByStudentId(Integer studentId);
	List<Book> findBooksByAuctionStatus(String auctionStatus);
	Boolean changeBookStatus(Integer bookId, String bookStatus);
	Boolean updateBookurl(Integer bookId, String booklink);
}
