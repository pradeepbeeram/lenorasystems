package com.book.rental.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.book.rental.delegates.MathUtils;
import com.book.rental.model.Book;

@Repository("bookDao")
public class BookDaoImpl extends AbstractDao<Integer, Book> implements BookDao{

	MathUtils utilities = new MathUtils();
	
	public void saveBook(Book bookDetails) {
		persist(bookDetails);
	}

	public Book getBookDetails(Integer BookId) {
		return getByKey(BookId);
	}

	public void deleteBook(Integer bookId) {
		Query query = getSession().createSQLQuery("delete from book where bookId = :bookId");
        query.setString(bookId, "bookId");
        query.executeUpdate();
	}
	
	@SuppressWarnings({ "unchecked"})
	public List<Book> findAllBooksByStudentId(Integer studentId) {
		
		Query query = getSession().createSQLQuery(" select * from book where Student_details_student_id = '"+studentId+"' ");
		List<Object[]> bookListObj = query.list();
		List<Book> bookList = new ArrayList<Book>();
		
		for(Object[] objects : bookListObj){
			Book book = new Book();
			book.setBookId(Integer.parseInt(objects[0].toString()));
			book.setBookAuctionStatus(objects[1].toString());
			book.setBookName(objects[2].toString());
			book.setBookDescription(objects[3].toString());
			if(objects[4] != null)
				book.setBookImage(objects[4].toString());
			book.setBookAuthor(objects[5].toString());
			book.setBookDetails(objects[6].toString());
			book.setBookType(objects[7].toString());
			book.setBookVersion(objects[8].toString());
			book.setStudentId(Integer.parseInt(objects[9].toString()));
			bookList.add(book);
		}
		
		return bookList;
	}
	
	/*@Override
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List findBooksByAuctionStatus(String auctionStatus) {
		Query query = getSession().createSQLQuery(" select b.*, a.auction_status from book b, auction a where book_auction_status = 'InAuction' and a.auction_status = 'Open' ");
		List<Object[]> bookListObj = query.list();
		List bookList = new ArrayList();
		List finalBooksList = new ArrayList();
		System.out.println(" findBooksByAuctionStatus in BOOKDAOIMPL");
		for(Object[] objects : bookListObj){
			Book book = new Book();
			bookList.add(Integer.parseInt(objects[0].toString()));
			bookList.add(objects[1].toString());
			bookList.add(objects[2].toString());
			bookList.add(objects[3].toString());
			if(objects[4] != null)
				bookList.add(objects[4].toString());
			bookList.add(objects[5].toString());
			bookList.add(objects[6].toString());
			bookList.add(objects[7].toString());
			bookList.add(objects[8].toString());
			bookList.add(Integer.parseInt(objects[9].toString()));
			bookList.add(objects[10].toString());
			finalBooksList.add(book);
		}
		return bookList;
	}*/

	@Override
	@SuppressWarnings("unchecked")
	public List<Book> findBooksByAuctionStatus(String auctionStatus) {
		Query query = getSession().createSQLQuery(" select * from book where book_auction_status = '"+auctionStatus+"' ");
		List<Object[]> bookListObj = query.list();
		List<Book> auctionBookList = new ArrayList<Book>();
		System.out.println(" findBooksByAuctionStatus in BOOKDAOIMPL");
		for(Object[] objects : bookListObj){
			Book book = new Book();
			book.setBookId(Integer.parseInt(objects[0].toString()));
			book.setBookAuctionStatus(objects[1].toString());
			book.setBookName(objects[2].toString());
			book.setBookDescription(objects[3].toString());
			if(objects[4] != null)
				book.setBookImage(objects[4].toString());
			book.setBookAuthor(objects[5].toString());
			book.setBookDetails(objects[6].toString());
			book.setBookType(objects[7].toString());
			book.setBookVersion(objects[8].toString());
			book.setStudentId(Integer.parseInt(objects[9].toString()));
			auctionBookList.add(book);
		}
		return auctionBookList;
	}

	@Override
	public Boolean changeBookStatus(Integer bookId, String bookStatus) {
		Query query = getSession().createSQLQuery(" update book set book_auction_status = '"+bookStatus+"' where book_id = '"+bookId+"' ");
        query.executeUpdate();
		return null;
	}
	
	public Boolean updateBookurl(Integer bookId, String booklink) {
		Query query = getSession().createSQLQuery(" update book set book_image = '"+booklink+"' where book_id = '"+bookId+"' ");
        query.executeUpdate();
		return null;
	}
	
}
