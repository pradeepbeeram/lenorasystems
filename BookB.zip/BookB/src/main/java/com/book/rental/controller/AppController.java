package com.book.rental.controller;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.joda.time.DateTime;
import org.joda.time.LocalDateTime;
import org.joda.time.Seconds;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.book.rental.delegates.BidDeclarer;
import com.book.rental.delegates.BookRentalSystemConstants;
import com.book.rental.delegates.DateUtilities;
import com.book.rental.emails.EmailHelper;
import com.book.rental.model.Auction;
import com.book.rental.model.BiddingDetails;
import com.book.rental.model.Book;
import com.book.rental.model.StudentDetails;
import com.book.rental.model.TransactionTable;
import com.book.rental.service.AuctionService;
import com.book.rental.service.BiddingDetailsService;
import com.book.rental.service.BookService;
import com.book.rental.service.StudentService;
import com.book.rental.service.TransactionService;

@Controller
@RequestMapping("/")
public class AppController {

	/**
	 * 
	 */
	@Autowired
	StudentService studentService;

	@Autowired
	BookService bookService;

	@Autowired
	AuctionService auctionService;

	@Autowired
	MessageSource messageSource;

	@Autowired
	BiddingDetailsService biddingDetailsService;

	@Autowired
	TransactionService transactionService;

	@Autowired
	ServletContext context;

	StudentDetails studentDetails;

	DateTime dateTime = new DateTime();

	EmailHelper emailHelper = new EmailHelper();
	String recipientEmail = "";
	String subject = "";
	String bodyMessage = "";

	// HttpSession session;

	@RequestMapping(value = { "/", "/home" }, method = RequestMethod.GET)
	public String hello(ModelMap model) {
		model.addAttribute("studentForm", new StudentDetails());
		return "home";
	}

	@RequestMapping(value = { "/register" }, method = RequestMethod.POST)
	public String doneRegistration(@ModelAttribute("studentForm") StudentDetails studentForm, Model model) {
		System.out.println("In register POST method");
		studentService.saveStudent(studentForm);
		System.out.println("studentForm " + studentForm.getStudent_first_name());
		System.out.println("studentForm ID" + studentForm.getStudentId());
		recipientEmail = studentForm.getStudentUcmEmailId();
		subject = "Welcome to Book Rental System by UCM";
		bodyMessage = " Hello " + studentForm.getStudent_first_name()
				+ ", \n We are happy to see you here. \n Enjoy the Features of Book Rentals.";
		emailHelper.emailSender(recipientEmail, subject, bodyMessage);
		return "redirect:/home";
	}

	@RequestMapping(value = { "/login" }, method = RequestMethod.POST)
	public String login(ModelMap model, HttpSession session, HttpServletRequest request, HttpServletResponse response) {
		model.addAttribute("studentForm", new StudentDetails());
		boolean loginAuthentication = false;
		if (request.getParameter("studentUcmId") != null || request.getParameter("password") != null) {
			String studentUcmId = request.getParameter("studentUcmId").toString();
			String studentPassword = request.getParameter("password").toString();
			loginAuthentication = studentService.authenticate(studentUcmId, studentPassword);
			System.out.println("loginAuthentication " + loginAuthentication);
			if (loginAuthentication == true) {
				studentDetails = studentService.findStudentByUcmId(studentUcmId);
				session.setAttribute("sessionStudentName", studentDetails.getStudent_first_name());
				session.setAttribute("sessionStudentId", studentDetails.getStudentId());
				System.out.println("sessionStudentId " + session.getAttribute("sessionStudentId"));

				// Email
				recipientEmail = studentDetails.getStudentUcmEmailId();
				subject = "Welcome Back to Book Rental System by UCM";
				bodyMessage = " Hello " + studentDetails.getStudent_first_name() + ", "
						+ "\n Welcome Back to Book Rental System." + "\n We Have Detected Login from your account."
						+ "\n Enjoy the Features of Book Rentals." + "\n \n \n Best Regards. \n Book Rental System";
				emailHelper.emailSender(recipientEmail, subject, bodyMessage);

				model.addAttribute("book", new Book());
				return "redirect:/myBooks";
			} else {
				model.addAttribute("message", "Authentication Failed !");
				return "home";
			}
		} else {
			model.addAttribute("message", "No Credentials");
			return "home";
		}
	}

	@RequestMapping(value = { "/myBooks" }, method = RequestMethod.GET)
	public String getMyBooks(ModelMap dasboardModels, HttpSession session, HttpServletResponse response)
			throws UnsupportedEncodingException {

		System.out.println("/dashboard GET Method");

		try {

			List<TransactionTable> transactionList = transactionService
					.getTransactionTable(Integer.parseInt(session.getAttribute("sessionStudentId").toString()));
			if (transactionList != null) {
				for (TransactionTable trans : transactionList) {
					LocalDateTime transactionEndLocal = DateUtilities
							.sqlTimestampToJodaLocalDateTime(trans.getTransactionEndTime());
					dateTime = transactionEndLocal.toDateTime();
					boolean transEndTimeExpire = DateUtilities.isGreater(dateTime);
					if (transEndTimeExpire == true) {
						Integer transAucId = trans.getAuctionId();
						Integer bookId = auctionService.getBookId(transAucId);
						bookService.changeBookStatus(bookId, BookRentalSystemConstants.BOOK_STATUS_NEW);
						transactionService.updateTransactionStatus(transAucId,
								BookRentalSystemConstants.TRANSACTION_STATUS_COMPLETED);
						auctionService.updateAuctionStatus(transAucId, BookRentalSystemConstants.AUCTION_STATUS_CLOSED);
					}
				}
			}

			/*
			 * List<Book> booksInAuction has the List of Books which are
			 * available for Auction from ALL Students.
			 */
			System.out.println("Break 1");
			List<Book> booksInAuction = bookService.findBooksByAuctionStatus(BookRentalSystemConstants.BOOK_STATUS_INAUCTION);
			System.out.println("booksInAuction size " + booksInAuction.size());
			dasboardModels.addAttribute("booksInAuction", booksInAuction);

			/*List<Auction> auctionEntity = new ArrayList<Auction>();

			System.out.println("Break 2");
			for (int i = 0; i < booksInAuction.size(); i++) {
				Book book = booksInAuction.get(i);
				System.out.println(
						"book ID " + book.getBookId() + " book.getBookAuctionStatus() " + book.getBookAuctionStatus());
				Auction auc = new Auction();

				if (book.getBookAuctionStatus().equals(BookRentalSystemConstants.BOOK_STATUS_INAUCTION)) {
					auc = auctionService.getAuctionDetails(book.getBookId(),
							BookRentalSystemConstants.AUCTION_STATUS_OPEN);
					System.out.println(" auc end time " + auc.getAuctionEndTime());
				}

				auctionEntity.add(auc);
				System.out.println("auctionEntity size " + auctionEntity.size());
				dasboardModels.addAttribute("auctionEntity", auctionEntity);dInt

			}*/

			

			HashMap<Integer, Integer> hashBidd = new HashMap<Integer, Integer>();
			hashBidd = biddingDetailsService
					.getAuctionBookDetails(Integer.parseInt(session.getAttribute("sessionStudentId").toString()));
			if (hashBidd.isEmpty()) {
				hashBidd.put(000, 000);
			}
			dasboardModels.addAttribute("bidsid", hashBidd);

			List<TransactionTable> transactionTable = transactionService
					.getTransactionTable(Integer.parseInt(session.getAttribute("sessionStudentId").toString()));
			dasboardModels.addAttribute("transactionTable", transactionTable);

		} catch (Exception e) {
			e.printStackTrace();
		}

		dasboardModels.addAttribute("book", new Book());
		dasboardModels.addAttribute("auction", new Auction());
		dasboardModels.addAttribute("transactions", new TransactionTable());

		try {
			/*
			 * List<Book> books has a List of Books Added by the Student Logged
			 * In.
			 */
			List<Book> books = bookService
					.findBooksByStudentId(Integer.parseInt(session.getAttribute("sessionStudentId").toString()));
			System.out.println("Books by student based on Student Id " + books);
			dasboardModels.addAttribute("books", books);

		} catch (NumberFormatException e) {
			e.printStackTrace();
		}

		return "dashboard";
	}

	@RequestMapping(value = { "/addBook" }, method = RequestMethod.POST)
	public String doneAddingBook(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			@RequestParam("fileSrc") MultipartFile file) throws ServletException, IOException {

		System.out.println(" In /addBookDetails POST Method ");

		System.out.println("Book name " + request.getParameter("bookName"));

		Book book = new Book();
		book.setBookAuthor(request.getParameter("bookAuthor"));
		book.setBookDescription(request.getParameter("bookDescription"));
		book.setBookDetails(request.getParameter("bookDetails"));
		book.setBookName(request.getParameter("bookName"));
		book.setBookType(request.getParameter("bookType"));
		book.setBookVersion(request.getParameter("bookVersion"));
		book.setBookAuctionStatus(BookRentalSystemConstants.BOOK_STATUS_NEW);
		book.setStudentId(Integer.parseInt(session.getAttribute("sessionStudentId").toString()));
		bookService.saveBook(book);

		System.out.println("book id " + book.getBookId());

		System.out.println("name " + file.getName());
		System.out.println("ORIGINAL NAME " + file.getOriginalFilename());

		String filePath = request.getServletContext().getRealPath("/");
		System.out.println("filePath " + filePath);

		String fileName = file.getOriginalFilename();

		context.getRealPath("/");
		String realPath = request.getSession().getServletContext().getRealPath("/resources/img");
		System.out.println("realPath " + realPath);

		// fileName = request.getParameter("bookName")
		// +"_"+Integer.parseInt(session.getAttribute("sessionStudentId").toString()+"_"+book.getBookId())+".jpg";
		fileName = book.getBookId() + "_" + file.getOriginalFilename();
		String fileDirPath = "C:/Users/aakas/workspace/BookB/src/main/webapp/resources/img";
		System.out.println("fileDirPath " + fileDirPath);
		
		File fileDir = new File(fileDirPath);
		
		File dest = new File(fileDir, fileName);
		file.transferTo(dest);

		bookService.updateBookurl(book.getBookId(), fileName);

		return "redirect:/myBooks";
	}

	@RequestMapping(value = { "/toAuction" }, method = RequestMethod.POST)
	public String postAuctionDetails(ModelMap auctionDetails, HttpServletResponse response, HttpServletRequest request,
			HttpSession session) {

		System.out.println("toAuction POST");
		System.out.println("no of hours " + request.getParameter("noOfHours"));
		System.out.println("maxAvailableDays " + request.getParameter("maxAvailableDays"));
		System.out.println("bookId " + request.getParameter("bookId"));

		final Integer auctionStudentId = Integer.parseInt(session.getAttribute("sessionStudentId").toString());
		Integer bookId = Integer.parseInt(request.getParameter("bookId"));
		Integer auctionRunningTimeinHrs = Integer.parseInt(request.getParameter("noOfHours"));

		DateTime dateTime = new DateTime();
		Timestamp aucStarttimeStamp = new Timestamp(dateTime.getMillis());
		System.out.println("aucStarttimeStamp ** "+aucStarttimeStamp);
		DateTime aucEndTime = new DateTime().plusHours(auctionRunningTimeinHrs);
		Timestamp aucEndtimeStamp = new Timestamp(aucEndTime.getMillis());
		System.out.println("aucEndtimeStamp ** "+aucEndtimeStamp);
		
		final Auction auction = new Auction();
		auction.setAuctionStudentId(auctionStudentId);
		auction.setBookId(bookId);
		auction.setAuctionStartTime(aucStarttimeStamp);
		auction.setAuctionEndTime(aucEndtimeStamp);
		auction.setAvailableDays(Integer.parseInt(request.getParameter("maxAvailableDays")));
		auction.setAuctionStatus(BookRentalSystemConstants.AUCTION_STATUS_OPEN);
		auctionService.insertAuctionDetails(auction);
		bookService.changeBookStatus(bookId, BookRentalSystemConstants.BOOK_STATUS_INAUCTION);

		studentDetails = studentService.findById(auctionStudentId);

		// Email
		recipientEmail = studentDetails.getStudentUcmEmailId();
		subject = "Book Added into Auction List";
		bodyMessage = " Hello " + studentDetails.getStudent_first_name() + ", "
				+ "\n We have added your book into Auctions List."
				+ "\n Soon you will receive the updates regrading your Auction." + "\n Auction wil be completed at "
				+ aucEndtimeStamp + " ." + "\n \n Enjoy the Features of Book Rentals."
				+ "\n \n \n Best Regards. \n Book Rental System";
		emailHelper.emailSender(recipientEmail, subject, bodyMessage);

		// Scheduler Starts Here.
		/*
		 * aucEndTime
		 */

		System.out.println("Break 0");
		
		LocalDateTime aucStartLocal = DateUtilities.sqlTimestampToJodaLocalDateTime(auction.getAuctionStartTime());
		DateTime aucStartDateTime = aucStartLocal.toDateTime();
		System.out.println("aucStartDateTime "+aucStartDateTime);
		
		LocalDateTime aucEndLocal = DateUtilities.sqlTimestampToJodaLocalDateTime(auction.getAuctionEndTime());
		DateTime aucEndDateTime = aucEndLocal.toDateTime();
		System.out.println("aucEndDateTime "+aucEndDateTime);
		
		Seconds diff = Seconds.secondsBetween(aucStartDateTime, aucEndDateTime);
		System.out.println("diff in seconds "+diff);
		Integer dInt = diff.getSeconds();
		System.out.println("dInt "+dInt);
		
		/*final Long endTime = (long) (dInt*1000);
		System.out.println("difference "+endTime);*/

		 final long endTime = 60000;

		System.out.println("auction details before " + auction.getAuctionId());

		// Scheduler Starts Here.
		
		Timer lTimer = new Timer();
		TimerTask lTimerTask = new TimerTask() {
			@Override
			public void run() {
				System.out.println("################# ");
				
				System.out.println("aucEndTimeExpire " + auction.getAuctionId() + " status " + auction.getAuctionStatus());
				try {
					@SuppressWarnings("rawtypes")
					List listBids = biddingDetailsService.getBidderDetails(auction.getAuctionId());
					System.out.println("listBids "+listBids);
					if (listBids == null || listBids.isEmpty()) {
						System.out.println("listBids null");
						auctionService.updateAuctionStatus(auction.getAuctionId(),
								BookRentalSystemConstants.AUCTION_STATUS_CLOSED);
						bookService.changeBookStatus(auction.getBookId(), BookRentalSystemConstants.BOOK_STATUS_NEW);

						studentDetails = studentService
								.findById(auctionStudentId);
						// Email
						recipientEmail = studentDetails.getStudentUcmEmailId();
						subject = "Update regarding your Auction";
						bodyMessage = " Hello " + studentDetails.getStudent_first_name() + ", " + "\n Your Auction is Closed."
								+ "\n We haven't received any Bidding for this Auction. Try One more time."
								+ "\n \n Enjoy the Features of Book Rentals." + "\n \n \n Best Regards. \n Book Rental System";
						emailHelper.emailSender(recipientEmail, subject, bodyMessage);
					} else {
						System.out.println("listBids sizev " + listBids.size());
						BidDeclarer bidDeclarer = new BidDeclarer();
						@SuppressWarnings({ "rawtypes", "unchecked" })
						List transList = bidDeclarer.Declare(listBids);

						TransactionTable transactionTable = new TransactionTable();
						transactionTable.setAuctionId(auction.getAuctionId());
						transactionTable.setAuctionStudentId(auction.getAuctionStudentId());
						transactionTable.setBiddingId((Integer) transList.get(1));
						transactionTable.setBiddingStudentId((Integer) transList.get(0));

						studentDetails = studentService.findById((Integer) transList.get(0));
						String biddintStudentName = studentDetails.getStudent_first_name() + " "
								+ studentDetails.getStudent_last_name();
						transactionTable.setBiddingStudentName(biddintStudentName);

						transactionTable.setTransactionAmount((Double) transList.get(3));

						DateTime transactionStart = new DateTime();
						Timestamp transactionStartTimeStamp = new Timestamp(transactionStart.getMillis());
						transactionTable.setTransactionTime(transactionStartTimeStamp);

						transactionStart = transactionStart.plusDays(auction.getAvailableDays());
						Timestamp transactionEndTimeStamp = new Timestamp(transactionStart.getMillis());
						// should get from auction days

						transactionTable.setTransactionEndTime(transactionEndTimeStamp);

						transactionTable.setTransactionStatus(BookRentalSystemConstants.TRANSACTION_STATUS_ASSIGNED);

						transactionService.insertTransaction(transactionTable);
						auctionService.updateAuctionStatus(auction.getAuctionId(),
								BookRentalSystemConstants.AUCTION_STATUS_IN_TRANSACTION);
						bookService.changeBookStatus(auction.getBookId(), BookRentalSystemConstants.BOOK_STATUS_RENTED);

						studentDetails = studentService
								.findById(auctionStudentId);
						// Email
						recipientEmail = studentDetails.getStudentUcmEmailId();
						String helloUser = studentDetails.getStudent_first_name();
						studentDetails = studentService.findById((Integer) transList.get(0));
						subject = "Update regarding your Auction";
						bodyMessage = " Hello " + helloUser + ", " + "\n Your Auction is Closed."
								+ "\n Book Rental System selected the Best Deal for you. Here are the Details."
								+ "\n Bidder Details " + "\n Name : " + studentDetails.getStudent_first_name() + " "
								+ studentDetails.getStudent_last_name() + " " + "\n 700# : " + studentDetails.getStudentUcmId()
								+ "" + "\n ucm Email : " + studentDetails.getStudentUcmEmailId() + " " + "\n Phone : "
								+ studentDetails.getStudentPhone() + " " + "\n Bidding Amount : " + transList.get(3) + " $"
								+ "\n Days Required : " + transList.get(2) + " Days"
								+ "\n \n Enjoy the Features of Book Rentals." + "\n \n \n Best Regards. \n Book Rental System";
						emailHelper.emailSender(recipientEmail, subject, bodyMessage);

					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				
				
				System.out.println("+++++++++++++++++");
			}
		};
	    lTimer.schedule(lTimerTask , endTime);

		auctionDetails.addAttribute("book", new Book());
		return "redirect:/myBooks";
	}

	@RequestMapping(value = { "/toBidding" }, method = RequestMethod.POST)
	public String toBiddingDetails(ModelMap biddingDetails, HttpServletResponse response, HttpServletRequest request,
			HttpSession session) {

		System.out.println(" /toBidding POST Method");

		Integer auctionBookId = Integer.parseInt(request.getParameter("bookId"));
		System.out.println("auctionBookId " + auctionBookId);
		Auction auction = auctionService.getAuctionDetails(auctionBookId,
				BookRentalSystemConstants.AUCTION_STATUS_OPEN);

		Integer auctionId = auction.getAuctionId();
		Integer int_biddingAmount = Integer.parseInt(request.getParameter("bidAmount"));
		Double biddingAmount = new Double(int_biddingAmount);
		/*
		 * Integer daysRequiredforRent =
		 * Integer.parseInt(request.getParameter("daysRequiredforRent"));
		 */

		BiddingDetails bidding = new BiddingDetails();
		bidding.setAmount(biddingAmount);
		bidding.setAuctionId(auctionId);
		bidding.setBiddingStudentId(Integer.parseInt(session.getAttribute("sessionStudentId").toString()));
		dateTime = new DateTime();
		Timestamp biddingTimeStamp = new Timestamp(dateTime.getMillis());
		bidding.setBidTime(biddingTimeStamp);
		/* bidding.setDaysRequired(daysRequiredforRent); */
		bidding.setBookId(auctionBookId);
		biddingDetailsService.saveBiddingDetails(bidding);

		studentDetails = studentService.findById(Integer.parseInt(session.getAttribute("sessionStudentId").toString()));
		// Email
		recipientEmail = studentDetails.getStudentUcmEmailId();
		subject = "Acknowledgment for your Bidding.";
		bodyMessage = " Hello " + studentDetails.getStudent_first_name() + ", " + "\n We have considered your bidding."
				+ "\n Soon you will receive the updates regrading your Biidding." + "\n Auction wil be completed at "
				+ auction.getAuctionEndTime() + " ." + "\n \n Enjoy the Features of Book Rentals."
				+ "\n \n \n Best Regards. \n Book Rental System";
		emailHelper.emailSender(recipientEmail, subject, bodyMessage);

		String biddedStudent = studentDetails.getStudent_first_name();
		// Email
		studentDetails = studentService.findById(auction.getAuctionStudentId());
		recipientEmail = studentDetails.getStudentUcmEmailId();
		subject = "Bidding Update for your Auction.";
		bodyMessage = " Hello " + studentDetails.getStudent_first_name() + ", " + "\n Student " + biddedStudent
				+ " Bidded for your Book with Amount " + biddingAmount + "."
				+ "\n Soon you will receive the updates regrading your Auction." + "\n Auction wil be completed at "
				+ auction.getAuctionEndTime() + " ." + "\n \n Enjoy the Features of Book Rentals."
				+ "\n \n \n Best Regards. \n Book Rental System";
		emailHelper.emailSender(recipientEmail, subject, bodyMessage);

		return "redirect:/myBooks";
	}
	
	@RequestMapping(value = {"/toTransaction"}, method= RequestMethod.GET)
	public String toTransaction(ModelMap dasboardModels, HttpSession session, HttpServletRequest request){
		
		System.out.println("toTransaction");
		
		System.out.println("transactionId "+request.getParameter("transactionId"));
		System.out.println("Request "+request.getParameter("bookGiven"));
		
		Integer transId = Integer.parseInt(request.getParameter("transactionId"));
		Integer auctionId = transactionService.getAuctionId(transId);
		Integer bookId = auctionService.getBookId(auctionId);
		
		if(request.getParameter("bookGiven").equals("Completed")){
			transactionService.updateTransactionStatus(transId, BookRentalSystemConstants.TRANSACTION_STATUS_COMPLETED);
			auctionService.updateAuctionStatus(auctionId, BookRentalSystemConstants.AUCTION_STATUS_CLOSED);
			bookService.changeBookStatus(bookId, BookRentalSystemConstants.BOOK_STATUS_NEW);
		}
		
		if(request.getParameter("bookGiven").equals("Book Given")){
			transactionService.updateTransactionStatus(transId, BookRentalSystemConstants.TRANSACTION_STATUS_BOOK_GIVEN);
			auctionService.updateAuctionStatus(auctionId, BookRentalSystemConstants.AUCTION_STATUS_IN_TRANSACTION);
			bookService.changeBookStatus(bookId, BookRentalSystemConstants.BOOK_STATUS_RENTED);
		}
		
		dasboardModels.addAttribute("book", new Book());
		dasboardModels.addAttribute("auction", new Auction());
		dasboardModels.addAttribute("transactions", new TransactionTable());
		
		return "redirect:/myBooks";
	}

	@RequestMapping(value = { "/logout" }, method = RequestMethod.GET)
	public String logout(ModelMap model, HttpSession session) {
		session.invalidate();
		model.addAttribute("studentForm", new StudentDetails());
		return "home";
	}

}