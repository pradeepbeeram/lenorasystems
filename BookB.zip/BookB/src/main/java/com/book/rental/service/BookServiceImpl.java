package com.book.rental.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.book.rental.dao.BookDao;
import com.book.rental.model.Book;


@Service("bookService")
@Transactional
public class BookServiceImpl implements BookService{

	@Autowired
	private BookDao bookDao;
	
	public Book findByBookId(Integer bookId) {
		return bookDao.getBookDetails(bookId);
	}

	public void saveBook(Book book) {
		bookDao.saveBook(book);
	}

	public void updateBook(Book book) {
		Book bookEntity = bookDao.getBookDetails(book.getBookId());
		if(bookEntity!=null){
			bookEntity.setBookName(book.getBookName());
			bookEntity.setBookAuthor(book.getBookAuthor());
			bookEntity.setBookDescription(book.getBookDescription());
			bookEntity.setBookAuctionStatus(book.getBookAuctionStatus());
			bookEntity.setBookDetails(book.getBookDetails());
			bookEntity.setBookImage(book.getBookImage());
			bookEntity.setBookType(book.getBookType());
			bookEntity.setBookVersion(book.getBookVersion());
		}
		
	}
	
	public void deleteBook(Integer bookId) {
		bookDao.deleteBook(bookId);
	}

	public List<Book> findBooksByStudentId(Integer studentId) {
		return bookDao.findAllBooksByStudentId(studentId);
	}

	public List<Book> findBooksByAuctionStatus(String auctionStatus) {
		return bookDao.findBooksByAuctionStatus(auctionStatus);
	}
	
	public Boolean changeBookStatus(Integer bookId, String bookStatus){
		return bookDao.changeBookStatus(bookId, bookStatus);
	}
	
	public Boolean updateBookurl(Integer bookId, String booklink) {
		return bookDao.updateBookurl(bookId, booklink);
	}

}
