package com.book.rental.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student_details")
public class StudentDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="student_id")
	private Integer studentId;
	
	/*
	@Size(min=3, max=50)
    @Column(name = "NAME", nullable = false)*/
	
	//@Size(min=9, max=11)
	@Column(name="student_ucm_id", nullable = false)
	private String studentUcmId;
	
	//@Size(min=4, max=20)
	@Column(name="student_first_name", nullable = false)
	private String student_first_name;
	
	//@Size(min=4, max=20)
	@Column(name="student_last_name", nullable = false)
	private String student_last_name;
	
	
	@Column(name="student_email_id", nullable = false)
	private String studentEmailId;
	
	@Column(name="student_ucm_email_id", nullable = false)
	private String studentUcmEmailId;
	
	//@Size(min=10, max=12)
	@Column(name="student_phone", nullable = false)
	private String studentPhone;
	
	//@Size(min=4, max=12)
	@Column(name="student_password", nullable = false)
	private String studentPassword;
	
	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public String getStudentUcmId() {
		return studentUcmId;
	}

	public void setStudentUcmId(String studentUcmId) {
		this.studentUcmId = studentUcmId;
	}

	public String getStudent_first_name() {
		return student_first_name;
	}

	public void setStudent_first_name(String student_first_name) {
		this.student_first_name = student_first_name;
	}

	public String getStudent_last_name() {
		return student_last_name;
	}

	public void setStudent_last_name(String student_last_name) {
		this.student_last_name = student_last_name;
	}

	public String getStudentEmailId() {
		return studentEmailId;
	}

	public void setStudentEmailId(String studentEmailId) {
		this.studentEmailId = studentEmailId;
	}

	public String getStudentUcmEmailId() {
		return studentUcmEmailId;
	}

	public void setStudentUcmEmailId(String studentUcmEmailId) {
		this.studentUcmEmailId = studentUcmEmailId;
	}

	public String getStudentPhone() {
		return studentPhone;
	}

	public void setStudentPhone(String studentPhone) {
		this.studentPhone = studentPhone;
	}

	public String getStudentPassword() {
		return studentPassword;
	}

	public void setStudentPassword(String studentPassword) {
		this.studentPassword = studentPassword;
	}

	
	
}
