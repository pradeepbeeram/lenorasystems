package com.book.rental.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="book")
public class Book {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="bookId")
	private Integer bookId;
	
	@Column(name="book_auction_status", nullable = false)
	private String bookAuctionStatus;
	
	@Column(name="book_name", nullable = false)
	private String bookName;
	
	@Column(name="book_description", nullable = false)
	private String bookDescription;
	
	@Column(name="book_image", nullable = true)
	private String bookImage;
	
	@Column(name="book_author", nullable = false)
	private String bookAuthor;
	
	@Column(name="book_details", nullable = false)
	private String bookDetails;
	
	@Column(name="book_type", nullable = false)
	private String bookType;
	
	@Column(name="book_version", nullable = false)
	private String bookVersion;
	
	@Column(name="Student_details_student_id", nullable=false)
	private Integer studentId;
	

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public Integer getBookId() {
		return bookId;
	}

	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}

	public String getBookAuctionStatus() {
		return bookAuctionStatus;
	}

	public void setBookAuctionStatus(String bookAuctionStatus) {
		this.bookAuctionStatus = bookAuctionStatus;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getBookDescription() {
		return bookDescription;
	}

	public void setBookDescription(String bookDescription) {
		this.bookDescription = bookDescription;
	}

	public String getBookImage() {
		return bookImage;
	}

	public void setBookImage(String bookImage) {
		this.bookImage = bookImage;
	}

	public String getBookAuthor() {
		return bookAuthor;
	}

	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}

	public String getBookDetails() {
		return bookDetails;
	}

	public void setBookDetails(String bookDetails) {
		this.bookDetails = bookDetails;
	}

	public String getBookType() {
		return bookType;
	}

	public void setBookType(String bookType) {
		this.bookType = bookType;
	}

	public String getBookVersion() {
		return bookVersion;
	}

	public void setBookVersion(String bookVersion) {
		this.bookVersion = bookVersion;
	}
	
	
	  
	

}
