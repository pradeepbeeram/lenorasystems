package com.book.rental.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="auction")
public class Auction {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="auction_id")
	private Integer auctionId;
	
	@Column(name="auction_student_id")
	private Integer auctionStudentId;
	
	@Column(name="book_id")
	private Integer bookId;
	
	@Column(name="auc_start_time")
	private Timestamp auctionStartTime;
	
	@Column(name="auc_end_time")
	private Timestamp auctionEndTime;
	
	@Column(name="available_days")
	private Integer availableDays;
	
	@Column(name="auction_status")
	private String auctionStatus;

	public Integer getAuctionId() {
		return auctionId;
	}

	public void setAuctionId(Integer auctionId) {
		this.auctionId = auctionId;
	}

	public Integer getAuctionStudentId() {
		return auctionStudentId;
	}

	public void setAuctionStudentId(Integer auctionStudentId) {
		this.auctionStudentId = auctionStudentId;
	}

	public Integer getBookId() {
		return bookId;
	}

	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}

	public Timestamp getAuctionStartTime() {
		return auctionStartTime;
	}

	public void setAuctionStartTime(Timestamp auctionStartTime) {
		this.auctionStartTime = auctionStartTime;
	}

	public Timestamp getAuctionEndTime() {
		return auctionEndTime;
	}

	public void setAuctionEndTime(Timestamp auctionEndTime) {
		this.auctionEndTime = auctionEndTime;
	}

	public Integer getAvailableDays() {
		return availableDays;
	}

	public void setAvailableDays(Integer availableDays) {
		this.availableDays = availableDays;
	}

	public String getAuctionStatus() {
		return auctionStatus;
	}

	public void setAuctionStatus(String auctionStatus) {
		this.auctionStatus = auctionStatus;
	}

	
	
	
}
