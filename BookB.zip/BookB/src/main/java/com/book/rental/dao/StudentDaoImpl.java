package com.book.rental.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.book.rental.model.StudentDetails;

@Repository("studengtDetailsDao")
public class StudentDaoImpl extends AbstractDao<Integer, StudentDetails> implements StudentDao {

	public StudentDetails findByStudentId(int id) {
		return getByKey(id);
	}

	public void saveStudentDetails(StudentDetails studentDetails) {
		persist(studentDetails);
		
	}

	public void deleteStudentByUcmId(String ucmId) {
		Query query = getSession().createSQLQuery("delete from student_details where student_ucm_id = :ucmId");
        query.setString(ucmId, "ucmId");
        query.executeUpdate();
		
	}

	@SuppressWarnings("unchecked")
	public List<StudentDetails> findAllStudents() {
		Criteria criteria = createEntityCriteria();
        return (List<StudentDetails>) criteria.list();
	}

	public StudentDetails findStudentByUcmId(String ucmId) {
		 Criteria criteria = createEntityCriteria();
	        criteria.add(Restrictions.eq("studentUcmId", ucmId));
	        return (StudentDetails) criteria.uniqueResult();
	}
	
	public boolean authenticate(String studentUcmId, String studentPassword){
		
		boolean authenticate = false;
		try {
			Query query = getSession().createSQLQuery("select student_password from student_details where student_ucm_id = '"+studentUcmId+"' ");

			String resultSetPassword = query.list().get(0).toString();
			System.out.println("resultSetPassword "+resultSetPassword);
			
			if(studentPassword.equals(resultSetPassword)){
				authenticate = true;
				System.out.println("studentPassword.equals true");
			}
		} catch (Exception e) {
			authenticate = false;
		}
		
		return authenticate;
	}
	

}
