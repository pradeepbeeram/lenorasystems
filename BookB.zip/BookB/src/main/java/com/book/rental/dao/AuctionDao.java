package com.book.rental.dao;

import java.util.List;

import com.book.rental.model.Auction;

public interface AuctionDao {
	
	Boolean insertAuctionDetails(Auction auctionDetails);
	Auction getAuctionDetails(Integer bookId, String auctionStatus);
	List<Auction> getAuctionOpenStatus(String auctionStatus);
	void updateAuctionStatus(Integer auctionId, String auctionStatus);
	Integer getBookId(Integer auctionId);

}
