package com.book.rental.dao;

import java.util.List;

import com.book.rental.model.StudentDetails;

public interface StudentDao {
	
	StudentDetails findByStudentId(int id);
	 
    void saveStudentDetails(StudentDetails studentDetails);
     
    void deleteStudentByUcmId(String ucmId);
     
    List<StudentDetails> findAllStudents();
 
    StudentDetails findStudentByUcmId(String ucmId);
    
    boolean authenticate(String studentUcmId, String studentPassword);

}
