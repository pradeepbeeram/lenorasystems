package com.book.rental.dao;

import java.util.List;

import com.book.rental.model.TransactionTable;

public interface TransactionDao {
	
	boolean insertTransaction(TransactionTable transaction);
	List<TransactionTable> getTransactionTable(Integer StudentId);
	boolean updateTransactionStatus(Integer transactionId, String TransactionStatus);
	Integer getAuctionId(Integer transactionId);

}
