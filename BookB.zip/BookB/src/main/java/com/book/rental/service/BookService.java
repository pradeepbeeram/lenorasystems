package com.book.rental.service;

import java.util.List;

import com.book.rental.model.Book;

public interface BookService {
	
	Book findByBookId(Integer bookId);
	
	void saveBook(Book book);
	
	void updateBook(Book book);
	
	void deleteBook(Integer bookId);
	
	List<Book> findBooksByStudentId(Integer studentId);
	
	List<Book> findBooksByAuctionStatus(String auctionStatus);
	
	Boolean changeBookStatus(Integer bookId, String bookStatus);
	
	Boolean updateBookurl(Integer bookId, String bookLink);
	
}
