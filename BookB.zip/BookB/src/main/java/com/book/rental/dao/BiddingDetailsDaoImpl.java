
package com.book.rental.dao;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.hibernate.Query;
import org.joda.time.DateTime;
import org.joda.time.LocalDateTime;
import org.springframework.stereotype.Repository;

import com.book.rental.delegates.DateUtilities;
import com.book.rental.model.BiddingDetails;

@Repository("biddingDao")
public class BiddingDetailsDaoImpl extends AbstractDao<Integer, BiddingDetails> implements BiddingDetailsDao{

	@Override
	public Boolean saveBiddingDetails(BiddingDetails biddings) {
		Boolean saveBiddingStatus = false;
		try {
			persist(biddings);
			saveBiddingStatus = true;
		} catch (Exception e) {
			saveBiddingStatus = false;
			e.printStackTrace();
		}
		return saveBiddingStatus;
	}

	@Override
	public BiddingDetails getBiddingDetails(Integer AuctionId) {


		return null;
	}
	
	
	@SuppressWarnings({ "unchecked" })
	public HashMap<Integer, Integer> getAuctionBookDetails(Integer studentId){
		
		Query query = getSession().createSQLQuery(" select bidding_details.Book_book_id, bidding_details.bidding_student_id from auction, bidding_details where auction.auction_id = bidding_details.Auction_auction_id and auction.auction_status = 'Open' and bidding_student_id = '"+studentId+"' ; ");
		List<Object[]> bookListObj = query.list();
		System.out.println("bookListObj size "+bookListObj.size());
		
		for(int i=0; i<bookListObj.size(); i++){
			System.out.println(" bookListObj "+ bookListObj.get(i));
		}
		
		HashMap<Integer, Integer> hm = new HashMap<Integer, Integer>();
		
		try {
			for(Object[] obj : bookListObj){
				System.out.println("obj[0].toString() "+obj[0].toString());
				System.out.println("obj[1].toString() "+obj[1].toString());
				
				hm.put(Integer.parseInt(obj[0].toString()), Integer.parseInt(obj[1].toString()));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return hm;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List getBidderDetails(Integer AuctionId){
		
		Query query = getSession().createSQLQuery(" select bidding_details.* from bidding_details, auction  where auction.auction_status = 'Open' and bidding_details.Auction_auction_id = auction.auction_id and auction.auction_id = '"+AuctionId+"' ");

		List<Object[]> bookListObj = query.list();
		
		List<List> listBiddingDetails = new ArrayList<List>();
		
		List<Integer> listStudentId = new ArrayList<Integer>();
		List<Double> listAmount = new ArrayList<Double>();
		/*List<Integer> listDays = new ArrayList<Integer>();*/
		List<DateTime> dateTimelist = new ArrayList<DateTime>();
		List<Integer> listBiddingId = new ArrayList<Integer>();
		
		try {
			for(Object[] obj : bookListObj){
				BiddingDetails biddingDetails = new BiddingDetails();
				listBiddingId.add(Integer.parseInt(obj[0].toString()));
				listStudentId.add((Integer.parseInt(obj[1].toString())));
				
				LocalDateTime aucEndLocal = DateUtilities.sqlTimestampToJodaLocalDateTime((Timestamp) obj[2]);
				DateTime dateTime = aucEndLocal.toDateTime();
				dateTimelist.add(dateTime);
				
				
				BigDecimal bd = (BigDecimal) obj[3];
				Double d = bd.doubleValue();
				listAmount.add(d);
				
				/*listDays.add((Integer) obj[4]);*/
				
				biddingDetails.setAuctionId((Integer) obj[4]);
				biddingDetails.setBookId((Integer) obj[5]);
				
				listBiddingDetails.add(listAmount);
				/*listBiddingDetails.add(listDays);*/
				listBiddingDetails.add(listStudentId);
				listBiddingDetails.add(dateTimelist);
				listBiddingDetails.add(listBiddingId);
				
			}
			System.out.println("getAuctionBookDetails() in bidding details dao impl ");
			
		} catch (Exception e) {
			e.printStackTrace();
			listBiddingDetails = null;
		}
		
		return listBiddingDetails;
	}
	
/*	@SuppressWarnings("unchecked")
	public List<BiddingDetails> getAuctionBookDetails(Integer bookId){
		Query query = getSession().createSQLQuery(" select bidding_details.* "
														+ "from bidding_details, auction "
														+ "where bidding_details.Book_book_id = auction.book_id "
														+ "and auction.auction_status = 'Open' "
														+ "and bidding_details.Book_book_id = '"+bookId+"'; ");
		
		List<Object[]> bookListObj = query.list();
		List<BiddingDetails> listBiddingDetails = new ArrayList<BiddingDetails>();
		try {
			for(Object[] obj : bookListObj){
				BiddingDetails biddingDetails = new BiddingDetails();
				biddingDetails.setBiddingId(Integer.parseInt(obj[0].toString()));
				biddingDetails.setBiddingStudentId(Integer.parseInt(obj[1].toString()));
				biddingDetails.setBidTime((Timestamp) obj[2]);
				biddingDetails.setAmount((BigDecimal) obj[3]);
				biddingDetails.setDaysRequired((Integer) obj[4]);
				biddingDetails.setAuctionId((Integer) obj[5]);
				biddingDetails.setBookId((Integer) obj[6]);
				listBiddingDetails.add(biddingDetails);
			}
			System.out.println("getAuctionBookDetails() in BOOKDAOIMPL");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listBiddingDetails;
	}*/
	
}
