package com.book.rental.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.book.rental.dao.StudentDao;
import com.book.rental.model.StudentDetails;

@Service("studentService")
@Transactional
public class StudentServiceImpl implements StudentService{
	
	@Autowired
	private StudentDao studentDao;

	public StudentDetails findById(int id) {
		return studentDao.findByStudentId(id);
	}

	public void saveStudent(StudentDetails studentDetails) {
		studentDao.saveStudentDetails(studentDetails);
	}

	public void updateStudent(StudentDetails studentDetails) {
		StudentDetails studentEntity = studentDao.findByStudentId(studentDetails.getStudentId());
		if(studentEntity!=null){
			studentEntity.setStudent_first_name(studentDetails.getStudent_first_name());
			studentEntity.setStudent_last_name(studentDetails.getStudent_last_name());
			studentEntity.setStudentEmailId(studentDetails.getStudentEmailId());
			studentEntity.setStudentPhone(studentDetails.getStudentPhone());
			studentEntity.setStudentUcmEmailId(studentDetails.getStudentUcmEmailId());
			studentEntity.setStudentUcmId(studentDetails.getStudentUcmId());
		}
	}

	public void deleteStudentByUcmId(String UcmId) {
		studentDao.deleteStudentByUcmId(UcmId);
	}

	public List<StudentDetails> findAllStudents() {
		return studentDao.findAllStudents();
	}

	public StudentDetails findStudentByUcmId(String UcmId) {
		return studentDao.findStudentByUcmId(UcmId);
	}

	public boolean isStudentUcmUnique(Integer id, String ucmId) {
		StudentDetails studentDetails = findStudentByUcmId(ucmId);
		return ( studentDetails == null || ((id != null) && (studentDetails.getStudentId() == id)));
	}

	public boolean authenticate(String studentUcmId, String studentPassword) {
		return studentDao.authenticate(studentUcmId, studentPassword);
	}

}
