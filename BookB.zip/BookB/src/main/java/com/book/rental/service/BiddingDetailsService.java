package com.book.rental.service;

import java.util.HashMap;
import java.util.List;

import com.book.rental.model.BiddingDetails;

public interface BiddingDetailsService {
	
	Boolean saveBiddingDetails(BiddingDetails biddings);
	BiddingDetails getBiddingDetails(Integer AuctionId);
	HashMap<Integer, Integer> getAuctionBookDetails(Integer studentId);
	@SuppressWarnings("rawtypes")
	List getBidderDetails(Integer AuctionId);
}
