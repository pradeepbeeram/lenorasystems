package com.book.rental.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="transaction_table")
public class TransactionTable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="transaction_id")
	private Integer transactionId;
	
	@Column(name="auction_student_id")
	private Integer auctionStudentId;
	
	@Column(name="bidding_student_id")
	private Integer biddingStudentId;
	
	@Column(name="transaction_time")
	private Timestamp transactionTime;
	
	@Column(name="transaction_status")
	private String transactionStatus;
	
	@Column(name="transaction_end_time")
	private Timestamp transactionEndTime;
	
	@Column(name="Auction_auction_id")
	private Integer auctionId;
	
	@Column(name="Bidding_details_bidding_id")
	private Integer biddingId;
	
	@Column(name="transaction_amount")
	private Double transactionAmount;
	
	@Column(name="bidding_student_name")
	private String biddingStudentName;

	public String getBiddingStudentName() {
		return biddingStudentName;
	}

	public void setBiddingStudentName(String biddingStudentName) {
		this.biddingStudentName = biddingStudentName;
	}

	public Integer getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}

	public Integer getAuctionStudentId() {
		return auctionStudentId;
	}

	public void setAuctionStudentId(Integer auctionStudentId) {
		this.auctionStudentId = auctionStudentId;
	}

	public Integer getBiddingStudentId() {
		return biddingStudentId;
	}

	public void setBiddingStudentId(Integer biddingStudentId) {
		this.biddingStudentId = biddingStudentId;
	}

	public Timestamp getTransactionTime() {
		return transactionTime;
	}

	public void setTransactionTime(Timestamp transactionTime) {
		this.transactionTime = transactionTime;
	}

	public String getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	public Timestamp getTransactionEndTime() {
		return transactionEndTime;
	}

	public void setTransactionEndTime(Timestamp transactionEndTime) {
		this.transactionEndTime = transactionEndTime;
	}

	public Integer getAuctionId() {
		return auctionId;
	}

	public void setAuctionId(Integer auctionId) {
		this.auctionId = auctionId;
	}

	public Integer getBiddingId() {
		return biddingId;
	}

	public void setBiddingId(Integer biddingId) {
		this.biddingId = biddingId;
	}

	public Double getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(Double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	
	
	
}
