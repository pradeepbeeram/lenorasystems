package com.book.rental.service;

import java.util.List;

import com.book.rental.model.Auction;

public interface AuctionService {
	
	Boolean insertAuctionDetails(Auction auctionDetails);
	Auction getAuctionDetails(Integer bookId, String auctionStatus);
	List<Auction> getAuctionOpenStatus(String auctionStatus);
	void updateAuctionStatus(Integer auctionId, String auctionStatus);
	Integer getBookId(Integer auctionId);

}
