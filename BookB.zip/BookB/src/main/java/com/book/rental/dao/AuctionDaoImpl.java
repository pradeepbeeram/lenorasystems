package com.book.rental.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.book.rental.model.Auction;

@Repository("auctionDao")
public class AuctionDaoImpl extends AbstractDao<Integer, Auction> implements AuctionDao{

	public Boolean insertAuctionDetails(Auction auctionDetails) {
		Boolean insertAuctionDetailsStatus = false;
		try {
			persist(auctionDetails);
			insertAuctionDetailsStatus = true;
		} catch (Exception e) {
			insertAuctionDetailsStatus = false;
			e.printStackTrace();
		}
		return insertAuctionDetailsStatus;
	}
	
	@SuppressWarnings("unchecked")
	public Auction getAuctionDetails(Integer bookId, String auctionStatus) {

		Query query = getSession().createSQLQuery(" select * from auction where auction.book_id = '"+bookId+"' and auction_status = '"+auctionStatus+"' ");
		 List<Object[]> listAuctionObject = query.list();
		 Auction auction = new Auction();
		 
			for(Object[] objects : listAuctionObject){
				auction.setAuctionId(Integer.parseInt(objects[0].toString()));
				auction.setAuctionStudentId(Integer.parseInt(objects[1].toString()));
				auction.setBookId(Integer.parseInt(objects[2].toString()));
				auction.setAuctionStartTime((Timestamp) objects[3]);
				auction.setAuctionEndTime((Timestamp) objects[4]);
				auction.setAvailableDays(Integer.parseInt(objects[5].toString()));
				auction.setAuctionStatus(objects[6].toString());
			}
		
		 return auction;
	}
	
	@SuppressWarnings({ "unchecked" })
	public List<Auction> getAuctionOpenStatus(String auctionStatus) {

		Query query = getSession().createSQLQuery("select * from auction where auction_status='"+auctionStatus+"' ");
		List<Object[]> listAuctionObject = query.list();
		
		List<Auction> auctionList = new ArrayList<Auction>();
		for(Object[] objects : listAuctionObject){
			Auction auction = new Auction();
			auction.setAuctionId(Integer.parseInt(objects[0].toString()));
			auction.setAuctionStudentId(Integer.parseInt(objects[1].toString()));
			auction.setBookId(Integer.parseInt(objects[2].toString()));
			auction.setAuctionStartTime((Timestamp) objects[3]);
			auction.setAuctionEndTime((Timestamp) objects[4]);
			auction.setAvailableDays(Integer.parseInt(objects[5].toString()));
			auction.setAuctionStatus(objects[6].toString());
			auctionList.add(auction);
		}
		return auctionList;
	}

	public void updateAuctionStatus(Integer auctionId, String auctionStatus) {
		Query query = getSession().createSQLQuery(" update auction set auction_status = '"+auctionStatus+"' where auction_id = '"+auctionId+"' ");
        query.executeUpdate();
	}
	
	public Integer getBookId(Integer auctionId) {
		Query query = getSession().createSQLQuery(" select book_id from auction where auction_id = '"+auctionId+"' ");
        Integer bookId =  (Integer) query.list().get(0);
        return bookId;
	}
	
	
/*
	@SuppressWarnings("unchecked")
	public Auction getAuctionDetails(Integer bookId, String auctionStatus) {

		Query query = getSession().createSQLQuery("select * from auction where book_id = '"+bookId+"' and auction_status='"+auctionStatus+"' ");
		List<Object[]> listAuctionObject = query.list();
		
		List<Auction> auctionList = new ArrayList<Auction>();
		
		for(Object[] obj : listAuctionObject){
			Auction auction = new Auction();
			auction.setAuctionId(Integer.parseInt(obj[0].toString()));
			auction.setAuctionStudentId(Integer.parseInt(obj[1].toString()));
			auction.setBookId(Integer.parseInt(obj[2].toString()));
			auction.setAuctionStartTime((Timestamp) obj[3]);
			auction.setAuctionEndTime((Timestamp) obj[4]);
			auction.setAvailableDays(Integer.parseInt(obj[5].toString()));
			auction.setAuctionStatus(obj[6].toString());
			auctionList.add(auction);
		}
		
		Auction auction = auctionList.get(0);
        return auction;
	}*/
		
}
