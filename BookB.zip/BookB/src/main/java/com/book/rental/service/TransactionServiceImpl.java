package com.book.rental.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.book.rental.dao.TransactionDao;
import com.book.rental.model.TransactionTable;

@Service("transactionService")
@Transactional
public class TransactionServiceImpl implements TransactionService{

	
	@Autowired
	private TransactionDao transactionDao;
	
	public boolean insertTransaction(TransactionTable transaction) {
		return transactionDao.insertTransaction(transaction);
	}

	public List<TransactionTable> getTransactionTable(Integer StudentId) {
		return transactionDao.getTransactionTable(StudentId);
	}

	public boolean updateTransactionStatus(Integer transactionId, String TransactionStatus){
		return transactionDao.updateTransactionStatus(transactionId, TransactionStatus);
	}
	
	public Integer getAuctionId(Integer transactionId){
		return transactionDao.getAuctionId(transactionId);
	}
	
	
	
}
