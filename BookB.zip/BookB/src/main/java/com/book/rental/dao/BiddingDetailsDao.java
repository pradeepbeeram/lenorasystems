package com.book.rental.dao;

import java.util.HashMap;
import java.util.List;

import com.book.rental.model.BiddingDetails;

public interface BiddingDetailsDao {
	
	Boolean saveBiddingDetails(BiddingDetails biddings);
	BiddingDetails getBiddingDetails(Integer AuctionId);
	HashMap<Integer, Integer> getAuctionBookDetails(Integer studentId);
	@SuppressWarnings("rawtypes")
	List getBidderDetails(Integer AuctionId);

}
