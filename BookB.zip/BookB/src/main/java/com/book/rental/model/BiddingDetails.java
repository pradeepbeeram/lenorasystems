package com.book.rental.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bidding_details")
public class BiddingDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="bidding_id")
	private Integer biddingId;
	
	@Column(name="bidding_student_id")
	private Integer biddingStudentId;
	
	@Column(name="bid_time")
	private Timestamp bidTime;
	
	@Column(name="amount")
	private Double amount;
	
	/*@Column(name="days_required")
	private Integer daysRequired;*/
	
	@Column(name="Auction_auction_id")
	private Integer auctionId;
	
	@Column(name="Book_book_id")
	private Integer bookId;

	public Integer getBookId() {
		return bookId;
	}

	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}

	public Integer getBiddingId() {
		return biddingId;
	}

	public void setBiddingId(Integer biddingId) {
		this.biddingId = biddingId;
	}

	public Integer getBiddingStudentId() {
		return biddingStudentId;
	}

	public void setBiddingStudentId(Integer biddingStudentId) {
		this.biddingStudentId = biddingStudentId;
	}

	public Timestamp getBidTime() {
		return bidTime;
	}

	public void setBidTime(Timestamp bidTime) {
		this.bidTime = bidTime;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Integer getAuctionId() {
		return auctionId;
	}

	public void setAuctionId(Integer auctionId) {
		this.auctionId = auctionId;
	}
	
	
	
	
}
