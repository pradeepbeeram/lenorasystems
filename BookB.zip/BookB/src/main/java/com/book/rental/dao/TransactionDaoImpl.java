package com.book.rental.dao;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.book.rental.model.TransactionTable;

@Repository("transactionDao")
public class TransactionDaoImpl extends AbstractDao<Integer, TransactionTable> implements TransactionDao{

	public boolean insertTransaction(TransactionTable transaction) {
		persist(transaction);
		return true;
	}
	
	@SuppressWarnings("unchecked")
	public List<TransactionTable> getTransactionTable(Integer studentId) {
		Query query = getSession().createSQLQuery(" SELECT * FROM transaction_table where auction_student_id = '"+studentId+"' ");
		List<Object[]> transListObj = query.list();
		
		List<TransactionTable> transList = new ArrayList<TransactionTable>();
		
		for(Object[] objects : transListObj){
			TransactionTable transTable = new TransactionTable();
			transTable.setTransactionId(Integer.parseInt(objects[0].toString()));
			transTable.setAuctionStudentId(Integer.parseInt(objects[1].toString()));
			transTable.setBiddingStudentId(Integer.parseInt(objects[2].toString()));
			transTable.setTransactionTime((Timestamp) objects[3]);
			transTable.setTransactionStatus(objects[4].toString());
			transTable.setTransactionEndTime((Timestamp) objects[5]);
			transTable.setAuctionId(Integer.parseInt(objects[6].toString()));
			transTable.setBiddingId(Integer.parseInt(objects[7].toString()));
			
			BigDecimal bd = (BigDecimal) objects[8];
			Double d = bd.doubleValue();
			transTable.setTransactionAmount(d);
			transTable.setBiddingStudentName(objects[9].toString());
			transList.add(transTable);
		}
		return transList;
	}
	
	
	public Integer getAuctionId(Integer transactionId){
		Integer auctionId = null;
		Query query = getSession().createSQLQuery("SELECT Auction_auction_id FROM transaction_table where transaction_id = '"+transactionId+"' ");
		auctionId = (Integer)query.list().get(0);
		System.out.println("auctionId in Transaction DAO IMPL "+auctionId);
		return auctionId;
	}
	
	
	public boolean updateTransactionStatus(Integer transactionId, String TransactionStatus){
		boolean updateTransactionStatus = false;
		try {
			Query query = getSession().createSQLQuery(" UPDATE transaction_table SET transaction_status = '"+TransactionStatus+"' WHERE transaction_id = '"+transactionId+"'; ");
			query.executeUpdate();
			updateTransactionStatus = true;
		} catch (Exception e) {
			updateTransactionStatus = false;
		}
		return updateTransactionStatus;
	}
	
	

}
