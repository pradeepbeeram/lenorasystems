package com.book.rental.delegates;

import java.sql.Date;
import java.sql.Timestamp;

import org.joda.time.DateTime;
import org.joda.time.LocalDateTime;

public class DateUtilities {

	public static void main(String[] args) {

		LocalDateTime localDateTime = new LocalDateTime();
	    System.out.println("LocalDateTime : " + localDateTime);
	    System.out.println("LocalDateTime to SQL Date : " + jodatToSQLDate(localDateTime));
	    Timestamp timestamp = jodaToSQLTimestamp(localDateTime);
	    System.out.println("LocalDateTime to SQL Timestamp : " + timestamp);
	    System.out.println("SQL Timestamp to LocalDateTime : " + sqlTimestampToJodaLocalDateTime(timestamp));
	  
	}
	
	public static boolean isGreater(DateTime compareDate){
		
		boolean isGreater = false;
		
		DateTime currentDateTime = new DateTime();
		
		if( currentDateTime.compareTo(compareDate) == 1 ) isGreater = true;
			else isGreater = false;

		return isGreater; 
	}
	
	
 
  public static Date jodatToSQLDate(LocalDateTime localDateTime) {
    return new Date(localDateTime.toDateTime().getMillis());
  }
 
  public static Timestamp jodaToSQLTimestamp(LocalDateTime localDateTime) {
    return new Timestamp(localDateTime.toDateTime().getMillis());
  }
 
  public static LocalDateTime sqlTimestampToJodaLocalDateTime(Timestamp timestamp) {
    return LocalDateTime.fromDateFields(timestamp);
  }
 

}
