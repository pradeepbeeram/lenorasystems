package com.book.rental.delegates;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.joda.time.DateTime;

public class BidDeclarer {
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List Declare(List<List> listBids){
		
		
		List finalReturnList;
		try {
			List<Double> listAmount = new ArrayList<Double>();
			listAmount = listBids.get(0);
			List<Integer> listStudentId = new ArrayList<Integer>();
			listStudentId = listBids.get(1);
			List<DateTime> dateTimelist = new ArrayList<DateTime>();
			dateTimelist = listBids.get(2);
			List<Integer> listBiddingId = new ArrayList<Integer>();
			listBiddingId = listBids.get(3);
			
			finalReturnList = new ArrayList<Integer>();
			
			Double bestAmount = Math.round(Collections.max(listAmount) * 100.0) / 100.0;
			
			List<Double> bestAmountList = new ArrayList<Double>();
			
			for(int i=0; i<listAmount.size(); i++){
				if(listAmount.get(i).equals(bestAmount)) {
					bestAmountList.add(listAmount.get(i));
				}
			}
			
			if(bestAmountList.size() == 1){
				
				for(int i=0; i<listAmount.size(); i++){
					if(listAmount.get(i).equals(bestAmount)){
						finalReturnList.add(listStudentId.get(i));
						finalReturnList.add(listBiddingId.get(i));
						finalReturnList.add(dateTimelist.get(i));
						finalReturnList.add(listAmount.get(i));
					}
				}
			}else{
				
				List<Integer> studentList = new ArrayList<Integer>();
				List<DateTime> dateList = new ArrayList<DateTime>();
				List<Integer> bidIdList = new ArrayList<Integer>();
				List<Double> amountList = new ArrayList<Double>();
				
				for(int i=0; i<listAmount.size();i++){
						if(listAmount.get(i).equals(bestAmount)){
							studentList.add((listStudentId.get(i)));
							dateList.add(dateTimelist.get(i));
							bidIdList.add(listBiddingId.get(i));
							amountList.add(listAmount.get(i));
						}
				}
				
				for(int i=0;i<dateList.size();i++){
					if(Collections.min(dateList) == dateList.get(i)){
						finalReturnList.add(studentList.get(i));
						finalReturnList.add(bidIdList.get(i));
						finalReturnList.add(dateList.get(i));
						finalReturnList.add(amountList.get(i));
					}
				}
				
			}
			
			System.out.println("Grand Final "+finalReturnList);
		} catch (Exception e) {
			e.printStackTrace();
			finalReturnList = null;
		}
		
		return finalReturnList;
	}
	
	
	public static void main(String[] args) {

		BidDeclarer t = new BidDeclarer();
		
		List<Integer> listStudentId = new ArrayList<Integer>();
		listStudentId.add(1);
		listStudentId.add(15);
		listStudentId.add(14);
		listStudentId.add(20);
		listStudentId.add(58);
		listStudentId.add(55);

		List<Double> listAmount = new ArrayList<Double>();
		listAmount.add(50.00);
		listAmount.add(7.00);
		listAmount.add(10.00);
		listAmount.add(8.00);
		listAmount.add(9.00);
		listAmount.add(10.00);
		
		DateTime currentDateTime = new DateTime();
		// System.out.println("currentDateTime "+currentDateTime);
		List<DateTime> dateTimelist = new ArrayList<DateTime>();
		dateTimelist.add(currentDateTime);
		dateTimelist.add(currentDateTime.plusHours(1));
		dateTimelist.add(currentDateTime.minusHours(5));
		dateTimelist.add(currentDateTime.minusHours(4));
		dateTimelist.add(currentDateTime.plusHours(5));
		dateTimelist.add(currentDateTime.minusHours(2));
		
		List<Integer> listBiddingId = new ArrayList<Integer>();
		listBiddingId.add(1);
		listBiddingId.add(2);
		listBiddingId.add(3);
		listBiddingId.add(4);
		listBiddingId.add(5);
		listBiddingId.add(6);
		
		@SuppressWarnings("rawtypes")
		List<List> listBids = new ArrayList<List>();
		listBids.add(listAmount);
		listBids.add(listStudentId);
		listBids.add(dateTimelist);
		listBids.add(listBiddingId);
		t.Declare(listBids);
		
	}
	
}
