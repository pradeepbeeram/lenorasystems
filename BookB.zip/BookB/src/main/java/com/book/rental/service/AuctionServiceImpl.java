package com.book.rental.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.book.rental.dao.AuctionDao;
import com.book.rental.model.Auction;

@Service("auctionService")
@Transactional
public class AuctionServiceImpl implements AuctionService{

	@Autowired
	private AuctionDao auctionDao;
	
	@Override
	public Boolean insertAuctionDetails(Auction auctionDetails) {
		return auctionDao.insertAuctionDetails(auctionDetails);
	}

	public Auction getAuctionDetails(Integer bookId, String auctionStatus){
		return auctionDao.getAuctionDetails(bookId, auctionStatus);
	}

	public List<Auction> getAuctionOpenStatus(String auctionStatus) {
		return auctionDao.getAuctionOpenStatus(auctionStatus);
	}

	@Override
	public void updateAuctionStatus(Integer auctionId, String auctionStatus) {
		auctionDao.updateAuctionStatus(auctionId, auctionStatus);
	}
	
	public Integer getBookId(Integer auctionId){
		return auctionDao.getBookId(auctionId);
	}
	
	
}
