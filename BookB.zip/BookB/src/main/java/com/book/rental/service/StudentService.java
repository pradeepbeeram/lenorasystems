package com.book.rental.service;

import java.util.List;

import com.book.rental.model.StudentDetails;

public interface StudentService {
	
	StudentDetails findById(int id);
    
    void saveStudent(StudentDetails studentDetails);
     
    void updateStudent(StudentDetails studentDetails);
     
    void deleteStudentByUcmId(String UcmId);
 
    List<StudentDetails> findAllStudents(); 
     
    StudentDetails findStudentByUcmId(String UcmId);
 
    boolean isStudentUcmUnique(Integer id, String ucmId);
    
    boolean authenticate(String studentUcmId, String studentPassword);

}
